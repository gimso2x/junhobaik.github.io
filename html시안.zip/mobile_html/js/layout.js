
$(document).ready(function () {
	// ====== lnb menu open ====== 
	$('.header_btn_menu').lnbMenu();
	// ====== lnb menu open ====== 
	
	// ====== lnb menu accordion ====== 
	$(document).on('click', '.menu_accodion a', function(){		
        var li = $(this).parent();
        $('.menu_accodion li .depth2').slideUp();
        if(!li.children('.depth2').is(":visible")){
            li.children('.depth2').slideDown();
        }
        
        var top_li = $(this).closest(".depth1_li");
        $(".depth1_li").removeClass("active");
		if(!top_li.hasClass("active")) {
			top_li.addClass("active");
		}
    });
	
	$('.menu_accodion .depth1_li').each(function() {
		if ($(this).find(".depth2").length === 0) {
			$(this).find(".areamove").remove();
		};
	});
	// ======  lnb menu accordion ====== 
});

//lnb menu open
(function ($) {
    $.fn.lnbMenu = function (opt) {
        var _href;
        var fadeSpeed = 400;

        if (opt === "close") {
            pop_close();
        }

        this.click(function () {
            _href = $('#menu_wrap');
            layer_popup(_href);
        });

        function layer_popup(el) {
            var _el = $(el); //���̾��� id�� _el ������ ����
            _el.show().animate({ right: '0' }, fadeSpeed);

            $('html,body').addClass("ov-hidden");

            _el.find('.menu_btn_back').click(function () { pop_close(); });
        }

        function pop_close() {
            $(_href).animate({ right: '-100%' }, fadeSpeed);
            setTimeout(function () { $(_href).hide(); }, fadeSpeed);

            $('html,body').removeClass("ov-hidden");
            return false;
        }
    };
})(jQuery);